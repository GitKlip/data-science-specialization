# Practical Machine Learning Assignment

The RMD file and html file are found (called index.rmd and index.html).
The HTML file is published at the following website: 

###(http://rjghartman.github.io/pml/)  

Reference for data: Ugulino, W.; Cardador, D.; Vega, K.; Velloso, E.; Milidiu, R.; Fuks, H. Wearable Computing: Accelerometers' Data Classification of Body Postures and Movements. Proceedings of 21st Brazilian Symposium on Artificial Intelligence. Advances in Artificial Intelligence - SBIA 2012
